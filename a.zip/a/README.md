Donation Bitcoin Here : 1uM8Bp7vchuJ5qsyd2iyPfqdnKMdyowan
,-.
        ___,---.__          /'|`\          __,---,___
     ,-'    \`    `-.____,-'  |  `-.____,-'    //    `-.
   ,'        |           ~'\     /`~           |        `.
  /      ___//              `. ,'          ,  , \___      \      
 |    ,-'   `-.__   _         |        ,    __,-'   `-.    |    
 |   /          /\_  `   .    |    ,      _/\          \   |
 \  |           \ \`-.___ \   |   / ___,-'/ /           |  /
  \  \           | `._   `\\  |  //'   _,' |           /  /
   `-.\         /'  _ `---'' , . ``---' _  `\         /,-'
      ``       /     \    ,='/ \`=.    /     \       ''
              |__   /|\_,--.,-.--,--._/|\   __|
              /  `./  \\`\ |  |  | /,//' \,'  \
             /   /     ||--+--|--+-/-|     \   \
            |   |     /'\_\_\ | /_/_/`\     |   |
             \   \__, \_     `~'     _/ .__/   /
              `-._,-'   `-._______,-'   `-._,-'
			  
#Author : Kadd3chy
#Date : 27/06/2018
#Version : 3,5
#Bot Vulns : 200 And More Soon :D


[+] Auto CMS Detecter [+]

[1] WordPress Vuln :
wpinstallcheck
revslider
addblockblocker
blaze
catpro
cherry
downloadsmanager
formcraft
levoslideshow
powerzoomer
gravityforms
getconfig
getconfig2
showbiz
ads
slideshowpro
wpmobiledetector
wysija
inboundiomarketing
dzszoomsounds
reflexgallery
sexycontactform
sexycontactform2
simpleplugin
wtffu
phpeventcalendar
synoptic
Wpshop
wpinjetc
gravityy
acento
ajaxstore
Antioch
Authentic
Churchope
Epic
Felis
Force
FR0
hbaudio
History
Imageex
kbslider
Linenity
Lote27
Markant
MichaelCanthony
mTheme
NativeChurch
Parallelus
RedSteel
Revsliderss
S3bubble
SMWF
TheLoft
Trinity
Urbancity
Yakimabait
Membership
FileManagerwp
Googlemp3
Justifiedim
Justified2
Justified3
Aspose
Asposedoc
MiwoFTP
MiwoFTP2
miniaudioplayer
Ypotheme
Media14
wpmon
mapprolbs
cubed
RightNow
konzept
omnisecurefiles
pitchprint
satoshi
pinboard
barclaycart
wpinjection

[2] Joomla Vuln : 

fox2
b22j
b2j
comjce
comedia
comjdownloads
comjdownloadsdef
comfabrik
comfabrikdef
comfabrik2
comfabrikdef2
hdflvplayer
comadsmanager
comblog
comusers
comweblinks
com_content
mod_simplefileupload
com_search
com_admin1
com_admin2
com_content1
com_content2
com_weblinks
com_mailto
com_content3
com_content4
com_users
com_installer
com_search1
com_poll
com_banners
com_mailto1
com_a6mambocredits
com_a6mambohelpdesk
com_advancedpoll
com_akocomment
com_articles
com_artlinks
com_trade
com_bayesiannaivefilter
com_babackup
redmy
facile
sujks
rocks
genesissimple
developertools
artuploader
fancys
hwdvideoshare
ksadvertiser
osproperty
collector
NovaSFH
Jimtawl
Proclaim

[3] DruPal Vuln : 

drupal
drupalgeddon

[4] PrestaShop Vuln :

columnadverts
soopamobile
soopabanners
vtermslideshow
simpleslideshow
productpageadverts
homepageadvertise
homepageadvertise2
jro_homepageadvertise
attributewizardpro
oneattributewizardpro
attributewizardproOLD
attributewizardpro_x
advancedslider
cartabandonmentpro
cartabandonmentproOld
videostab
wg24themeadministration
fieldvmegamenu
wdoptionpanel
pk_flexmenu
pk_vertflexmenu
nvn_export_orders
megamenu
tdpsthemeoptionpanel
psmodthemeoptionpanel
masseditproduct


I hope You Enjoy This Tool ♥

Contact Me :
ICQ : 729325418
Facebook : fb.me/Kadd3chy.phtml
Mail : moat3z.kadd3chy@gmail.com
Instagram : instagram.com/Kadd3chy/
Skype : moatez.kaddchy2
YouTube Channel : https://www.youtube.com/channel/UCOoDkpd9aB4Z-bCxXncGh9g
